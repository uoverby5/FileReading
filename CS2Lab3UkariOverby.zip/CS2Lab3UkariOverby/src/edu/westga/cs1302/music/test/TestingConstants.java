package edu.westga.cs1302.music.test;

/**
 * The class TestingConstants.
 * 
 * @author CS 1302
 * @version Spring 2023
 */
public final class TestingConstants {

	public static final double DELTA = 0.000001;

}
