package edu.westga.cs1302.music.test.playlist;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import edu.westga.cs1302.music.model.Playlist;
import edu.westga.cs1302.music.model.Song;

class TestFilterSongs {

	private static final String SONG_FILTERED = "Checking if song was filtered";

	@Test
	void testYearInvalid() {
		//ARRANGE
		Playlist playlist = new Playlist();
		
		//ACT && ASSERT
		assertThrows(IllegalArgumentException.class, ()->{
			playlist.filterSongs(1899, 2);
		});
	}
	
	@Test
	void testNegativeNumOfSongs() {
		//ARRANGE
		Playlist playlist = new Playlist();
		
		//ACT && ASSERT
		assertThrows(IllegalArgumentException.class, ()->{
			playlist.filterSongs(1900, -1);
		});
	}
	
	@Test
	void testNoSongsFiltered() {
		//ARRANGE
		Playlist playlist = new Playlist();
		Song song1 = new Song("Title1", "Artist1", 1, 31, 2021);
		playlist.add(song1);
		
		//ACT
		ArrayList<Song> expected = playlist.filterSongs(1900, 1);
		
		//ASSERT
		assertEquals(null, expected, SONG_FILTERED);
		
	}
	
	@Test
	void testOneSongFiltered() {
		//ARRANGE
		Playlist playlist = new Playlist();
		Song song1 = new Song("Title1", "Artist1", 1, 31, 2021);
		playlist.add(song1);
		ArrayList<Song> filtered = new ArrayList<Song>();
		filtered.add(song1);
		
		//ACT
		ArrayList<Song> expected = playlist.filterSongs(2021, 1);
		
		//ASSERT
		assertEquals(filtered, expected, SONG_FILTERED);
		
	}
	
	@Test
	void testTwoSongsFiltered() {
		//ARRANGE
		Playlist playlist = new Playlist();
		Song song1 = new Song("Title1", "Artist1", 1, 31, 2021);
		Song song2 = new Song("Title2", "Artist2", 1, 31, 2021);
		playlist.add(song1);
		playlist.add(song2);
		ArrayList<Song> filtered = new ArrayList<Song>();
		filtered.add(song1);
		filtered.add(song2);
		
		//ACT
		ArrayList<Song> expected = playlist.filterSongs(2021, 2);
		
		//ASSERT
		assertEquals(filtered, expected, SONG_FILTERED);
		
	}
	
	@Test
	void testSomeSongsFilteredNotAll() {
		//ARRANGE
		Playlist playlist = new Playlist();
		Song song1 = new Song("Title1", "Artist1", 1, 31, 2021);
		Song song2 = new Song("Title2", "Artist2", 1, 31, 2021);
		Song song3 = new Song("Title3", "Artist3", 1, 31, 2020);
		playlist.add(song1);
		playlist.add(song2);
		playlist.add(song3);
		
		ArrayList<Song> filtered = new ArrayList<Song>();
		filtered.add(song1);
		filtered.add(song2);
		
		//ACT
		ArrayList<Song> expected = playlist.filterSongs(2021, 2);
		
		//ASSERT
		assertEquals(filtered, expected, SONG_FILTERED);
		
	}
	
	@Test
	void testFilteredSongsLessThanAmountAskedFor() {
		//ARRANGE
		Playlist playlist = new Playlist();
		Song song1 = new Song("Title1", "Artist1", 1, 31, 2021);
		Song song2 = new Song("Title2", "Artist2", 1, 31, 2021);
		Song song3 = new Song("Title3", "Artist3", 1, 31, 2020);
		playlist.add(song1);
		playlist.add(song2);
		playlist.add(song3);
		
		ArrayList<Song> filtered = new ArrayList<Song>();
		filtered.add(song1);
		filtered.add(song2);
		
		//ACT
		ArrayList<Song> expected = playlist.filterSongs(2021, 3);
		
		//ASSERT
		assertEquals(filtered, expected, SONG_FILTERED);
		
	}
		

}
