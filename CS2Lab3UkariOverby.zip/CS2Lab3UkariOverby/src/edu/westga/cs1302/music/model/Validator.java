package edu.westga.cs1302.music.model;

/**
 * The class Validator.
 * 
 * @author CS 1302
 * @version Spring 2023
 */
public class Validator {

	private static final String INVALID_YEAR_ERROR = "Whole number required with 4 digits";
	private static final String REQUIRED_FIELD = "This field is required";
	private static final String SECONDS_ERROR_MESSAGE = "Whole number required with at most 2 digits";
	private static final String MINUTES_ERROR_MESSAGE = "Whole number required, with at most 3 digits";
	
	private String minutesError;
	private String secondsError;
	private String yearError;

	/**
	 * Instantiates a new Validator.
	 * 
	 * @precondition none
	 * @postcondition getMinutesError().isEmpty() && getSecondsError().isEmpty() &&
	 *                getYearError().isEmpty()
	 */
	public Validator() {
		this.reset();
	}

	/**
	 * Returns the minutesError of this Validator.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the minutesError
	 */
	public String getMinutesError() {
		return this.minutesError;
	}

	/**
	 * Returns the secondsError of this Validator.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the secondsError
	 */
	public String getSecondsError() {
		return this.secondsError;
	}

	/**
	 * Returns the yearError of this Validator.
	 * 
	 * @precondition none
	 * @postcondition none
	 * @return the yearError
	 */
	public String getYearError() {
		return this.yearError;
	}

	/**
	 * Found error.
	 *
	 * @precondition none
	 * @postcondition none
	 * 
	 * @return true, if a preceding call to a validation method detected an error
	 */
	public boolean foundError() {
		return !this.minutesError.isEmpty() || !this.secondsError.isEmpty() || !this.yearError.isEmpty();
	}

	/**
	 * Validate minutes. Removes trailing and leading spaces from specified
	 * minutesString. Checks if the resulting string represents a valid minutes
	 * value and sets a suitable error message. A valid value has to be a whole
	 * number >= 0 and can only have at most three digits.
	 *
	 * @precondition none
	 * @postcondition getMinutesError().isEmpty() if the passed-in string represents
	 *                a valid value for the minutes variable; otherwise
	 *                getMinutesError() returns a suitable error message
	 *
	 * @param minutesString the string representing minutes
	 * @return the value represented by minutesString after leading and trailing
	 *         spaces have been removed; null if minutesString does not represent a
	 *         valid minutes value
	 */
	public Integer validateMinutes(String minutesString) {
		if (minutesString == null) {
			this.minutesError = REQUIRED_FIELD;
			return null;
		}
		if (minutesString.isEmpty()) {
			this.minutesError = REQUIRED_FIELD;
			return null;
		}
		
		int value = Integer.parseInt(minutesString.trim());
		
		if (minutesString.matches("\\d{1,3}")) {
			this.minutesError.isEmpty();
		} else {
			this.minutesError = MINUTES_ERROR_MESSAGE;
		}
	
		return value;
	}

	/**
	 * Validate seconds. Removes trailing and leading spaces from specified
	 * secondsString. Checks if the resulting string represents a valid seconds
	 * value and sets a suitable error message. A valid value has to be a number >=
	 * 0 and can only have 2 digits.
	 *
	 * @precondition none
	 * @postcondition getSecondsError().isEmpty() if the passed in string represents
	 *                a valid value for the seconds variable; otherwise
	 *                getSecondsError() returns a suitable error message
	 *
	 * @param secondsString the string representing seconds
	 * @return the value represented by secondsString after leading and trailing
	 *         spaces have been removed; null if secondsString does not represent a
	 *         valid seconds value
	 */
	public Integer validateSeconds(String secondsString) {
		if (secondsString == null) {
			this.secondsError = REQUIRED_FIELD;
			return null;
		}

		int value = Integer.parseInt(secondsString.trim());

		if (secondsString.matches("\\d{1,2}")) {
			this.minutesError.isEmpty();
		} else {
			this.secondsError = SECONDS_ERROR_MESSAGE;
		}
		
		return value;

	}

	/**
	 * Validate the specified yearString. Removes trailing and leading spaces from
	 * specified yearString. Checks if the resulting string represents a valid year
	 * and sets a suitable error message. A valid year has to be a number with four
	 * digits, where the first number cannot be 0.
	 *
	 * @precondition none
	 * @postcondition getYearError().isEmpty() if the passed in string represents a
	 *                valid year; otherwise getYearError() returns an suitable error
	 *                message
	 * 
	 * @param yearString the string representing the year of a song
	 * @return the value represented by yearString after leading and trailing spaces
	 *         have been removed; null if yearString does not represent a valid year
	 */
	public Integer validateYear(String yearString) {
		
		if (yearString == null) {
			this.yearError = REQUIRED_FIELD;
			return null;
		}
		
		int value = Integer.parseInt(yearString.trim());
		
		if (yearString.matches("\\d{4}")) {
			this.yearError.isEmpty();
		} else {
			this.yearError = INVALID_YEAR_ERROR;
		}
		
		return value;
	}

	/**
	 * Resets validator.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void reset() {
		this.minutesError = "";
		this.secondsError = "";
		this.yearError = "";
	}
}
